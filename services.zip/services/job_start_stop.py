
import Warehouse.constants as Constants
import json
from SharedApp.services.rabbitmq_handler import RabbitMQHandler
from Warehouse.enums import RayJobStatusEnum
from rest_framework import status
from Warehouse import logger
from ICD.Settings.base import *
import sys
import ray
import json
from ray.job_submission import JobSubmissionClient
import Warehouse.constants as Constants
from Warehouse import logger
import Warehouse.config as Config
import os 
from ICD.Settings.base import *
import Warehouse.error_messages as Message
from SocketioApp.socket_connection import data_sender_to_client
import Warehouse.error_messages as Message
from rest_framework.response import Response
import Warehouse.log_constants as LogConstants
from Warehouse.models.base_model import RayJobInfo
from datetime import datetime
class JobStartStop(object):
    
    """
        data send to the ray, while job creation or job stop.
    """

    def job_start_signal_send_to_service(self, inference_start_obj):
        
        """
            Description: send start signal to the ray job need to start
            args: inference_start_obj 
        """
        
        if IS_RAY_SERVICE_RUNNING:
            return self.start_stop_ray_job(inference_start_obj)
        else:
            logger.debug("{}, {}, {}, {}, {}".format(LogConstants.KEY_CTMS_SERVICE,LogConstants.KEY_SURVEY_APP,LogConstants.KEY_WAREHOUSE_START_RAY_JOB,"ray connection",IS_RAY_SERVICE_RUNNING))
        

    def job_stop_signal_send_to_service(self, inference_stop_obj):
        
        """
            Description: send stop signal to the ray job to be stop.
            args: inference_stop_obj
        """
        if IS_RAY_SERVICE_RUNNING:
            return self.start_stop_ray_job(inference_stop_obj)
        else:
            logger.debug("{}, {}, {}, {}, {}".format(LogConstants.KEY_CTMS_SERVICE,LogConstants.KEY_SURVEY_APP,LogConstants.KEY_WAREHOUSE_STOP_RAY_JOB,"ray connection",IS_RAY_SERVICE_RUNNING))
    
    def start_stop_ray_job(self,data):
        
        """
            Description: start ray job cargo count inference need to be start.
            args: data
        """
        
        try:
            data['base_url'] = Config.BASE_URL

            logger.info("{},{},{},{},{}".format(LogConstants.KEY_CTMS_SERVICE,LogConstants.KEY_SURVEY_APP,LogConstants.KEY_RAY_JOB_RESPONSE_SIGNAL,"Ray job submission process",Config.ray_client_url))
            client = JobSubmissionClient(Config.ray_client_url)
            run_script = "sh run.sh '{}'".format(json.dumps(data))
            job_id = client.submit_job(entrypoint=run_script,runtime_env={"working_dir":str(os.getcwd())+"/Warehouse/services"})
            logger.info("{},{},{},{},{},{}".format(LogConstants.KEY_CTMS_SERVICE,LogConstants.KEY_SURVEY_APP,LogConstants.KEY_RAY_JOB_RESPONSE_SIGNAL,data[Constants.KEY_OP_TYPE],"Ray job submitted- ray job ID",job_id))
            ray_obj = RayJobInfo.objects.filter(cargo_job_id=data[Constants.KEY_JOB_ID])
            if data[Constants.KEY_OP_TYPE] == Constants.KEY_START:
                if ray_obj:
                    ray_obj.update(ray_start_job_id= str(job_id),ray_job_status = RayJobStatusEnum.START_JOB_SUBMITTED.value, updated_time = datetime.now().strftime(Constants.KEY_DATE_FORMAT))
                else:
                    RayJobInfo.objects.create(cargo_job_id=data[Constants.KEY_JOB_ID],ray_start_job_id=str(job_id), created_time = datetime.now().strftime(Constants.KEY_DATE_FORMAT), ray_job_status = RayJobStatusEnum.START_JOB_SUBMITTED.value)
            if data[Constants.KEY_OP_TYPE] == Constants.KEY_STOP:
                ray_obj.update(ray_stop_job_id= str(job_id),ray_job_status = RayJobStatusEnum.STOP_JOB_SUBMITTED.value, updated_time = datetime.now().strftime(Constants.KEY_DATE_FORMAT))
            return Response({Constants.KEY_MESSAGE:"Ray job submitted successfully"},status=status.HTTP_200_OK)
        except (ConnectionError, ConnectionRefusedError) as e:
            logger.exception("{},{},{},{}".format(LogConstants.KEY_CTMS_SERVICE,LogConstants.KEY_SURVEY_APP,LogConstants.KEY_RAY_JOB_RESPONSE_SIGNAL,"ConnectionError occured while trying to connect to Ray service"))
            print("ray-exception","ConnectionError ", e)
            return Response({Constants.KEY_MESSAGE:Message.KEY_RAY_SERVICE_NOT_AVAILABLE},status=status.HTTP_503_SERVICE_UNAVAILABLE)
        except RuntimeError as e:
            logger.exception("{},{},{},{}".format(LogConstants.KEY_CTMS_SERVICE,LogConstants.KEY_SURVEY_APP,LogConstants.KEY_RAY_JOB_RESPONSE_SIGNAL,"RuntimeError occured while submitting job to Ray service"))
            print("ray-exception","RunTimeError ", e)
            return Response({Constants.KEY_MESSAGE:Message.KEY_RAY_FAILED_TO_INITIATE_JOB},status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        except Exception as e:
            logger.exception("{},{},{},{}".format(LogConstants.KEY_CTMS_SERVICE,LogConstants.KEY_SURVEY_APP,LogConstants.KEY_RAY_JOB_RESPONSE_SIGNAL,"Exception occured while submitting job to Ray service"))
            print("ray-exception","Exception ", e)
            return Response({Constants.KEY_MESSAGE:Message.KEY_RAY_OTHER_EXCEPTION},status=status.HTTP_500_INTERNAL_SERVER_ERROR)
