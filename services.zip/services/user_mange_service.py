import jwt
from Warehouse import logger


def extract_user_name(request):
    """
    extract the jwt token and get user logged in user name
    """
    try:
        token_value = str(request.META.get('HTTP_AUTHORIZATION').split(' ')[1])
        decoded_payload = jwt.decode(token_value, options={"verify_signature": False})
        username=decoded_payload["identity"]["username"]
    except Exception as e:
        return logger.logger_error(["Extract UserName"],"authorization token was not given",e)
    return username